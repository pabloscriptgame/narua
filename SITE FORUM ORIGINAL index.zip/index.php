<?php
session_start();

// ==================== CONEXÃO COM SQLITE ====================
$dbFile = __DIR__ . '/forum.db';
try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro ao conectar no banco: " . htmlspecialchars($e->getMessage()));
}

// ==================== CRIAÇÃO DAS TABELAS ====================
$pdo->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    email TEXT,
    created DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$pdo->exec("CREATE TABLE IF NOT EXISTS complaints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'Aberta',
    created DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$pdo->exec("CREATE TABLE IF NOT EXISTS replies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    complaint_id INTEGER,
    message TEXT NOT NULL,
    is_admin INTEGER DEFAULT 0,
    created DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// Admin padrão (senha: p4bl0)
$hash = password_hash('p4bl0', PASSWORD_DEFAULT);
$pdo->exec("INSERT OR IGNORE INTO users (username, password, email) 
            VALUES ('admin', '$hash', 'admin@naruarpg.com')");

$section = $_GET['section'] ?? 'home';
$msg = '';

// ==================== LOGIN ====================
if (isset($_POST['login'])) {
    $username = trim($_POST['username'] ?? '');
    $pass = $_POST['pass'] ?? '';

    if (empty($username) || empty($pass)) {
        $msg = '❌ Preencha nick e senha';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($pass, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $msg = '✅ Login realizado!';
            header("Location: ?section=home");
            exit;
        } else {
            $msg = '❌ Nick ou senha incorretos';
        }
    }
}

// ==================== CADASTRO ====================
if (isset($_POST['register'])) {
    $username = trim($_POST['username'] ?? '');
    $pass = $_POST['pass'] ?? '';
    $email = trim($_POST['email'] ?? '');

    if (strlen($username) < 3) {
        $msg = '❌ Nick deve ter pelo menos 3 caracteres';
    } elseif (strlen($pass) < 8) {
        $msg = '❌ Senha deve ter no mínimo 8 caracteres';
    } else {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, password, email) VALUES (?,?,?)");
            $stmt->execute([$username, $hash, $email ?: null]);
            $msg = '✅ Conta criada! Faça login.';
            header("Location: ?section=login");
            exit;
        } catch (PDOException $e) {
            $msg = (stripos($e->getMessage(), 'UNIQUE') !== false) 
                ? '❌ Este nick já está em uso' 
                : '❌ Erro ao criar conta';
        }
    }
}

// ==================== LOGOUT ====================
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: ?section=home");
    exit;
}

// ==================== NOVA RECLAMAÇÃO ====================
if (isset($_POST['submit_complaint']) && isset($_SESSION['user_id'])) {
    $title = trim($_POST['title'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (strlen($title) < 5 || strlen($message) < 10) {
        $msg = '❌ Título precisa ter pelo menos 5 caracteres e mensagem pelo menos 10';
    } else {
        $stmt = $pdo->prepare("INSERT INTO complaints (user_id, title, message) VALUES (?,?,?)");
        $stmt->execute([$_SESSION['user_id'], $title, $message]);
        $msg = '✅ Reclamação enviada com sucesso!';
        header("Location: ?section=complaints");
        exit;
    }
}

// ==================== RESPOSTA ADMIN ====================
if (isset($_POST['reply']) && isset($_SESSION['username']) && $_SESSION['username'] === 'admin') {
    $reply_msg = trim($_POST['reply_msg'] ?? '');
    $complaint_id = (int)($_POST['complaint_id'] ?? 0);

    if ($complaint_id > 0 && strlen($reply_msg) > 5) {
        $stmt = $pdo->prepare("INSERT INTO replies (complaint_id, message, is_admin) VALUES (?,?,1)");
        $stmt->execute([$complaint_id, $reply_msg]);
        $msg = '✅ Resposta enviada!';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NaRua RPG • Painel de Reclamações</title>
    <link rel="icon" type="image/png" href="https://iili.io/qBukOIR.png">
    <style>
        :root {
            --neon: #c300ff;
            --neon-dark: #9d00cc;
            --glow: 0 0 25px rgba(195,0,255,0.7);
            --card: rgba(28,8,55,0.82);
            --border: rgba(195,0,255,0.45);
            --text: #f2eaff;
            --muted: #c19fff;
        }
        body {
            background: #0a0012;
            color: var(--text);
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }
        #bg-video {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            object-fit: cover;
            z-index: -2;
            filter: brightness(0.45) contrast(1.1);
        }
        #overlay {
            position: fixed;
            inset: 0;
            background: linear-gradient(rgba(10,0,18,0.75), rgba(28,8,55,0.85));
            z-index: -1;
        }
        header {
            position: fixed;
            top: 0; left: 0; right: 0;
            background: rgba(18,5,45,0.92);
            border-bottom: 3px solid var(--neon-dark);
            backdrop-filter: blur(12px);
            z-index: 1000;
            padding: 1rem 5%;
            box-shadow: 0 6px 35px rgba(0,0,0,0.7);
        }
        .header-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo-area {
            display: flex;
            align-items: center;
            gap: 1.2rem;
        }
        .logo-area img { height: 60px; filter: drop-shadow(var(--glow)); }
        .logo-area span {
            font-size: 2.2rem;
            font-weight: 900;
            letter-spacing: 4px;
            background: linear-gradient(90deg, #ff66ff, var(--neon));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        nav ul {
            display: flex;
            list-style: none;
            gap: 2rem;
            margin: 0;
            padding: 0;
        }
        nav a {
            color: var(--text);
            text-decoration: none;
            font-weight: 600;
            padding: 0.8rem 1.5rem;
            border-radius: 12px;
            transition: all 0.3s;
        }
        nav a:hover, nav a.active {
            background: rgba(195,0,255,0.18);
            box-shadow: var(--glow);
        }
        .main-content {
            max-width: 1400px;
            margin: 110px auto 60px;
            padding: 0 20px;
        }
        .glass-card {
            background: var(--card);
            backdrop-filter: blur(12px);
            border: 1px solid var(--border);
            border-radius: 18px;
            padding: 2.5rem;
            margin-bottom: 2.5rem;
            box-shadow: 0 15px 60px rgba(0,0,0,0.6);
        }
        h1, h2 {
            text-align: center;
            margin-bottom: 2rem;
            background: linear-gradient(90deg, white, var(--neon));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: var(--glow);
        }
        input, textarea {
            width: 100%;
            padding: 1.2rem;
            margin: 1rem 0;
            background: rgba(255,255,255,0.07);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: white;
            font-size: 1.1rem;
        }
        textarea { min-height: 160px; resize: vertical; }
        .btn {
            background: linear-gradient(135deg, var(--neon-dark), var(--neon));
            color: white;
            border: none;
            padding: 1.2rem 2.5rem;
            border-radius: 12px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: var(--glow);
            width: 100%;
        }
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 50px rgba(195,0,255,0.6);
        }
        .toast {
            position: fixed;
            bottom: 40px; left: 50%;
            transform: translateX(-50%);
            background: var(--neon);
            color: #111;
            padding: 1.4rem 3rem;
            border-radius: 14px;
            font-weight: bold;
            z-index: 9999;
            box-shadow: var(--glow);
            display: none;
        }

        /* ==================== MENU RESPONSIVO ==================== */
        .hamburger {
            display: none;
            flex-direction: column;
            gap: 6px;
            cursor: pointer;
        }
        .hamburger span {
            width: 28px;
            height: 3px;
            background-color: var(--text);
            transition: all 0.3s ease;
            border-radius: 2px;
        }

        /* Tabela responsiva */
        .table-responsive {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
        }
        th, td {
            padding: 1.2rem;
            text-align: left;
            background: rgba(40,15,80,0.45);
            border: 1px solid var(--border);
        }
        th {
            background: linear-gradient(135deg, var(--neon-dark), var(--neon));
            color: white;
            text-transform: uppercase;
            font-size: 0.95rem;
        }
        tr {
            cursor: pointer;
            transition: all 0.3s;
        }
        tr:hover {
            transform: translateY(-4px);
            box-shadow: var(--glow);
        }
        td:first-child { border-radius: 12px 0 0 12px; }
        td:last-child { border-radius: 0 12px 12px 0; }

        @media (max-width: 768px) {
            .hamburger {
                display: flex;
            }
            nav ul {
                display: none !important;
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                background: rgba(18,5,45,0.98);
                flex-direction: column;
                gap: 0.8rem;
                padding: 1.5rem 5%;
                border-top: 1px solid var(--border);
                box-shadow: 0 15px 40px rgba(0,0,0,0.7);
                z-index: 9999;
            }
            nav ul.show {
                display: flex !important;
            }
            /* Animação do hamburger */
            .hamburger.active span:nth-child(1) {
                transform: rotate(45deg) translate(5px, 5px);
            }
            .hamburger.active span:nth-child(2) {
                opacity: 0;
                transform: translateX(20px);
            }
            .hamburger.active span:nth-child(3) {
                transform: rotate(-45deg) translate(6px, -6px);
            }

            .table-responsive table thead { display: none; }
            tr {
                display: block;
                margin-bottom: 1.5rem;
                border-radius: 12px;
                overflow: hidden;
            }
            td {
                display: block;
                text-align: right;
                border: none;
                border-bottom: 1px solid var(--border);
                position: relative;
                padding-left: 50%;
            }
            td:before {
                content: attr(data-label);
                position: absolute;
                left: 1.5rem;
                width: 45%;
                font-weight: bold;
                color: var(--neon);
                text-align: left;
            }
        }
    </style>
</head>
<body>

<video autoplay muted loop playsinline id="bg-video">
    <source src="https://archive.org/download/los-santos-night-drive-gta-sa/Los%20Santos%20Night%20Drive%20-%20GTA%20SA.mp4" type="video/mp4">
</video>
<div id="overlay"></div>

<?php if($msg): ?>
<div class="toast" style="display:block;"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<header>
    <div class="header-container">
        <div class="logo-area">
            <img src="https://iili.io/qBukOIR.png" alt="NaRua">
            <span>NaRua RPG</span>
        </div>

        <nav>
            <ul id="navMenu">
                <li><a href="?section=home" class="<?= $section=='home'?'active':'' ?>">Início</a></li>
                <li><a href="?section=complaints" class="<?= $section=='complaints'?'active':'' ?>">Reclamações</a></li>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li><a href="?section=new">Nova Reclamação</a></li>
                <?php endif; ?>
                <?php if(!isset($_SESSION['user_id'])): ?>
                    <li><a href="?section=register">Criar Conta</a></li>
                    <li><a href="?section=login">Entrar</a></li>
                <?php else: ?>
                    <li><a><?= htmlspecialchars($_SESSION['username']) ?></a></li>
                    <li><a href="?logout=1">Sair</a></li>
                <?php endif; ?>
                <?php if(isset($_SESSION['username']) && $_SESSION['username']==='admin'): ?>
                    <li><a href="?section=admin" style="color:#ff66cc;">Admin</a></li>
                <?php endif; ?>
            </ul>
        </nav>

        <div class="hamburger">
            <span></span><span></span><span></span>
        </div>
    </div>
</header>

<div class="main-content">

<?php if($section === 'home'): ?>
    <div class="glass-card" style="text-align:center;">
        <h1>Painel Oficial de Reclamações</h1>
        <p style="font-size:1.4rem; color:var(--muted); margin:2rem 0;">
            Registre denúncias, bugs, sugestões ou dúvidas do servidor NaRua RPG.<br>
            A administração responde o mais rápido possível.
        </p>
        <div style="margin:3rem 0; display:flex; gap:2rem; justify-content:center; flex-wrap:wrap;">
            <a href="?section=complaints" class="btn">Ver Reclamações</a>
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="?section=new" class="btn" style="background:linear-gradient(135deg,#00c853,#00b140);">Nova Reclamação</a>
            <?php else: ?>
                <a href="?section=login" class="btn">Fazer Login para Enviar</a>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php if($section === 'complaints'): ?>
    <div class="glass-card">
        <h2>Reclamações Registradas</h2>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Autor</th>
                        <th>Data</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $stmt = $pdo->query("SELECT c.id, c.title, u.username, c.created, c.status 
                                     FROM complaints c 
                                     LEFT JOIN users u ON c.user_id = u.id 
                                     ORDER BY c.created DESC");
                $rows = $stmt->fetchAll();
                if ($rows):
                    foreach ($rows as $row):
                ?>
                    <tr onclick="location.href='?section=view&id=<?= $row['id'] ?>'">
                        <td data-label="ID">#<?= $row['id'] ?></td>
                        <td data-label="Título"><?= htmlspecialchars(substr($row['title'], 0, 60)) . (strlen($row['title']) > 60 ? '...' : '') ?></td>
                        <td data-label="Autor"><?= htmlspecialchars($row['username'] ?? 'Anônimo') ?></td>
                        <td data-label="Data"><?= date('d/m/Y H:i', strtotime($row['created'])) ?></td>
                        <td data-label="Status"><strong style="color:<?= $row['status'] === 'Aberta' ? '#ffcc00' : '#00ff9d' ?>"><?= $row['status'] ?></strong></td>
                        <td data-label="Ações"><a href="?section=view&id=<?= $row['id'] ?>" style="color:var(--neon);">Ver</a></td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="6" style="text-align:center; padding:4rem;">Nenhuma reclamação registrada ainda.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<?php if($section === 'new' && isset($_SESSION['user_id'])): ?>
    <div class="glass-card">
        <h2>Enviar Nova Reclamação</h2>
        <form method="post">
            <input type="text" name="title" placeholder="Título da reclamação (mín. 5 caracteres)" required>
            <textarea name="message" placeholder="Descreva o problema com detalhes (mín. 10 caracteres)" required></textarea>
            <button type="submit" name="submit_complaint" class="btn">REGISTRAR RECLAMAÇÃO</button>
        </form>
    </div>
<?php elseif($section === 'new'): ?>
    <div class="glass-card" style="text-align:center;">
        <p style="font-size:1.4rem; margin:2rem 0;">Você precisa estar logado para enviar reclamações.</p>
        <a href="?section=login" class="btn">Fazer Login</a>
    </div>
<?php endif; ?>

<?php if($section === 'view' && isset($_GET['id'])):
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT c.*, u.username FROM complaints c LEFT JOIN users u ON c.user_id = u.id WHERE c.id = ?");
    $stmt->execute([$id]);
    $complaint = $stmt->fetch();
    if (!$complaint):
?>
    <div class="glass-card" style="text-align:center;">
        <p>Reclamação não encontrada.</p>
    </div>
<?php else:
    $replies = $pdo->prepare("SELECT * FROM replies WHERE complaint_id = ? ORDER BY created");
    $replies->execute([$id]);
?>
    <div class="glass-card">
        <h2><?= htmlspecialchars($complaint['title']) ?></h2>
        <div style="background:rgba(40,15,80,0.4); padding:1.8rem; border-radius:12px; margin:1.5rem 0;">
            <?= nl2br(htmlspecialchars($complaint['message'])) ?>
        </div>
        <div style="font-size:0.95rem; color:var(--muted);">
            Por <?= htmlspecialchars($complaint['username'] ?? 'Anônimo') ?> • 
            <?= date('d/m/Y H:i', strtotime($complaint['created'])) ?> • 
            Status: <strong style="color:<?= $complaint['status'] === 'Aberta' ? '#ffcc00' : '#00ff9d' ?>"><?= $complaint['status'] ?></strong>
        </div>
    </div>

    <div class="glass-card">
        <h3>Respostas da Administração</h3>
        <?php foreach ($replies->fetchAll() as $reply): ?>
            <div style="margin:1.5rem 0; padding:1.5rem; background:rgba(195,0,255,0.1); border-left:5px solid var(--neon); border-radius:10px;">
                <?= nl2br(htmlspecialchars($reply['message'])) ?>
                <div style="margin-top:1rem; font-size:0.9rem; color:var(--muted);">
                    Staff • <?= date('d/m/Y H:i', strtotime($reply['created'])) ?>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if(isset($_SESSION['username']) && $_SESSION['username'] === 'admin'): ?>
            <form method="post" style="margin-top:2.5rem;">
                <textarea name="reply_msg" placeholder="Resposta da administração..." required></textarea>
                <input type="hidden" name="complaint_id" value="<?= $id ?>">
                <button type="submit" name="reply" class="btn">Enviar Resposta (Admin)</button>
            </form>
        <?php endif; ?>
    </div>
<?php endif; endif; ?>

<?php if($section === 'register'): ?>
    <div class="glass-card">
        <h2>Criar Conta</h2>
        <form method="post">
            <input type="text" name="username" placeholder="Nome do Nick do Game" required>
            <input type="email" name="email" placeholder="E-mail (opcional)">
            <input type="password" name="pass" placeholder="Senha (mínimo 8 caracteres)" required>
            <button type="submit" name="register" class="btn">CADASTRAR CONTA</button>
        </form>
    </div>
<?php endif; ?>

<?php if($section === 'login'): ?>
    <div class="glass-card">
        <h2>Fazer Login</h2>
        <form method="post">
            <input type="text" name="username" placeholder="Nome do Nick do Game" required>
            <input type="password" name="pass" placeholder="Senha" required>
            <button type="submit" name="login" class="btn">ENTRAR</button>
        </form>
    </div>
<?php endif; ?>

</div>

<script>
    // ==================== MENU RESPONSIVO ====================
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.getElementById('navMenu');

    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            navMenu.classList.toggle('show');
            hamburger.classList.toggle('active');
        });

        // Fechar menu ao clicar em qualquer link (melhor experiência mobile)
        const links = navMenu.querySelectorAll('a');
        links.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('show');
                hamburger.classList.remove('active');
            });
        });
    }

    // Toast timeout
    setTimeout(() => {
        document.querySelectorAll('.toast').forEach(t => t.style.display = 'none');
    }, 6000);
</script>
</body>
</html>